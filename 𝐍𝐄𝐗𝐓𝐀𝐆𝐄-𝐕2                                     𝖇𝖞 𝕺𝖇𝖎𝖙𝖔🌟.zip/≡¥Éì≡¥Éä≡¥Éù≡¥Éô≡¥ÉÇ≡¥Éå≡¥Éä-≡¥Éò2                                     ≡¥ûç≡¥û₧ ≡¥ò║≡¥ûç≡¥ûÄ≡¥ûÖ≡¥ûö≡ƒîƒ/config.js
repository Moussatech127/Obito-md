require("./database/module")

//GLOBAL PAYMENT
global.storename = "𝕺𝖇𝖎𝖙𝖔🌟𝔫𝔢𝔵𝔱𝔞𝔤𝔢༒"
global.dana = "221771084464"
global.qris = "gada qris gw anjg"


// GLOBAL SETTING
global.owner = "221771084463"
global.namabot = "𝐍𝐄𝐗𝐓𝐀𝐆𝐄-𝐕2"
global.nomorbot = "221771084463"
global.namaCreator = "𝕺𝖇𝖎𝖙𝖔🌟𝔫𝔢𝔵𝔱𝔞𝔤𝔢༒"
global.linkyt = ""
global.autoJoin = false
global.antilink = false
global.versisc = '2.0.0'

// DELAY JPM
global.delayjpm = 5500

// SETTING PANEL
global.apikey = 'PLTC'
global.capikey = 'PLTA'
global.domain = 'https://domain.com'
global.eggsnya = '15'
global.location = '1'



//GLOBAL THUMB

global.codeInvite = ""
global.imageurl = ''
global.isLink = ''
global.packname = "Fatal"
global.author = "𝕺𝖇𝖎𝖙𝖔🌟"
global.jumlah = "5"


let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
})